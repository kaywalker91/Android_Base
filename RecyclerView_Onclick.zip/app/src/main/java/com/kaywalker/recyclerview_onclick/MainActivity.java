package com.kaywalker.recyclerview_onclick;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<User> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userList = new ArrayList<>();

        setUserInfor();
        setAdapter();

    }

    private void setAdapter() {
        recyclerAdapter adapter = new recyclerAdapter(userList);
    }

    private void setUserInfor() {
        userList.add(new User("kay"));
        userList.add(new User("jay"));
        userList.add(new User("tay"));
        userList.add(new User("pay"));
    }
}